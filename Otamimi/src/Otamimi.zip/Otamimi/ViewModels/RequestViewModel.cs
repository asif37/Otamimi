﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Otamimi.Models;

namespace Otamimi.ViewModels
{
    public class RequestViewModel
    {
        public Misfund misFunds { get; set; }
        public Refund refund { get; set; }
    }
}
