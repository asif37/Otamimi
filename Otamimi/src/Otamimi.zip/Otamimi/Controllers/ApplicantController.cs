using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Otamimi.Data;

namespace Otamimi.Controllers
{
    public class ApplicantController : Controller
    {
        public IActionResult Index()
        {
            using (var db=new ApplicationDbContext())
            {
                ViewBag.BanksList =db.Banks.ToList();
                ViewBag.CountryList = db.Countries.ToList();
            }
           
            return View(new Otamimi.ViewModels.RequestViewModel());
        }
    }
}